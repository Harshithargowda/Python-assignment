#!/usr/bin/python3

#####################################################################################
#                                                                                   #
#    Prob: Implement a python code to draw a 2-D plot for student registration      #
#          number and the marks secured (use gnu plot)                              #
#                                                                                   #
#####################################################################################

import Gnuplot
from numpy import *

regnum=[]
marks_all=[]

print("Hello, Please enter total 5 reg num and marks")

for a in range(1,6):

    user = input("Reg. num: ")
    regnum.append(user)
    marks = input("marks: ")
    marks_all.append(marks)

plt = Gnuplot.Gnuplot()    
plt.plot(regnum, marks_all)

plt.xlabel('Students')
plt.ylabel('Marks')
plt.title('Program 21')
#plt.savefig("test-21.png")
#plt.show()
#hardcopy (filename='rainfall-intensity.png', terminal='png') 

plt('set xdata time')

d1=Gnuplot.Data(regnum,marks_all,with_="line")

plt.show(d1)   #uncomment this line if you want to see the gnuplot window
plt.hardcopy('filename.png',terminal = 'png')
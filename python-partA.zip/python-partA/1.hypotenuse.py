#!/usr/bin/python

from math import sqrt
print("Input the length of  shorter sides of triangle: ")
a=float(input("a: "))
b=float(input("b: "))
c=sqrt(a**2+b**2)
print("the length of the hypotenuse is", c)

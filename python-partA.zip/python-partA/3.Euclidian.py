#!/usr/bin/python
import math
print("enter the vertices  X1 and Y1 of point 1: ")
X1=float(input("side of X1 is:"))
Y1=float(input("side of Y1 is:"))
print("enter the vertices X2 and Y2 of point 2: ")
X2=float(input("side of X2 is:"))
Y2=float(input("side of Y2 is:"))
distance=math.sqrt((X2-X1)*(X2-X1)+(Y2-Y1)*(Y2-Y1))
print(" Euclidian distance between two points",distance)
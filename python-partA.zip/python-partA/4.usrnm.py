#!/usr/bin/python
import getpass
print("enter the username")
name=input("username:")
print("enter the password")
password=getpass.getpass()
print("username:",name, "password:",password)
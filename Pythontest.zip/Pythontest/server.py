import sys
import socket
 
HOST = ''   
PORT = 8888 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Socket created')
 
try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
    sys.exit()
     
print('Socket bind complete')
 
s.listen(5)
print('Socket now listening')
 
#accept a connection
conn, addr = s.accept()
 
print('Connected with ' + addr[0] + ':' + str(addr[1]))
 
#connection with the client
data = conn.recv(1024)
conn.sendall(data)
 
conn.close()
s.close()

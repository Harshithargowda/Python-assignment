
import mysql.connector
from mysql.connector import Error
def insert_patient(patient_id, patient_firstName, patient_secondName , sex , birthdate, ssn, street, city , zipcode):
    query = "INSERT INTO patient(patient_id, patient_firstName, patient_secondName , sex , birthdate, ssn, street, city , zipcode) " \
            "VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"

    args = (patient_id, patient_firstName, patient_secondName , sex , birthdate, ssn, street, city , zipcode)
 
    try:
        conn = mysql.connector.connect(host='localhost',
                                       database='patientdatabase',
                                       user='root',
                                       password='*****')
        if conn.is_connected():
            print('Connected to MySQL database')
 
 
        cursor = conn.cursor()
        cursor.execute(query, args)
 
        if cursor.lastrowid:
            print('last insert id', cursor.lastrowid)
        else:
            print('last insert id not found')
 
        conn.commit()
    except Error as error:
        print(error)
 
    finally:
        cursor.close()
        conn.close()
 
def main():
    userpatient_id=input("Enter patient_id:");
    userpatient_firstName=input("Enter patient_firstName:");
    userpatient_secondName=input("Enter patient_secondName:");
    usersex=input("Enter patient_sex:");
    userbirthdate=input("Enter date of birth:");
    userssn=input("Enter ssn:");
    userstreet=input("Enter street:");
    usercity=input("Enter city:");
    userzipcode=input("Enter zipcode:");
    insert_patient(userpatient_id, userpatient_firstName, userpatient_secondName ,usersex, userbirthdate, userssn, userstreet,usercity , userzipcode)
 
if __name__ == '__main__':
    main()
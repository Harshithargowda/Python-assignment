
import mysql.connector
from mysql.connector import Error
def connect():
	# conn to the database
	conn = mysql.connector.connect(host='localhost',
									database='patientdatabase',
									user='root',
									password='*****')
	if conn.is_connected():
		print('Connected to database')
	choice=int(input("Enter your choice:\n1.insert\n2.Retrieve\n3.Exit: "))
	while(1):
		if choice==1:
			insert_laborders(conn)
		elif choice==2:
			retrieve_laborders(conn)
		else:
			conn.close()
			break
		choice=int(input("\nEnter your choice:\n1.insert\n2.Retrieve\n3.Exit: "))


def insert_laborders(conn):
	''' To insert the values '''
	cursor=conn.cursor()

	# values to be added from the user
	choice='y'
	while(choice=='y'):
		print("Enter the values:")
		order_id=input("Enter order_id:")
		patient_id=input("Enter patient_id:")
		visit_id=input("Enter visit_id:")
		provider_id=input("Enter provider_id:")
		transaction_date= input("Enter transaction_date:")
		charges=input("Enter charges:")
		site_id=input("Enter site_id: ")
		entered_by=input("Enter entered_by: ")
		
		try:
			
			query="insert into lab_orders values(%s,%s,%s,%s,%s,%s,%s,%s)"
			args=(order_id, patient_id, visit_id, provider_id, transaction_date, charges, site_id, entered_by)

			cursor.execute(query,args)
			conn.commit()
			print ("\nValues inserted\n")
			choice=input("Add more values? y: ")
		except Error as e:
			print (e)


def retrieve_laborders(conn):
	
	cursor=conn.cursor()

	# create the query
	query="select * from lab_orders"

	# execute  query and fetchall
	cursor.execute(query)
	
	rows=cursor.fetchall()

	for row in rows:
		print (row)
connect()


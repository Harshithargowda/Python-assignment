
import mysql.connector
from mysql.connector import Error
def connect():
	# conn to the database
	conn = mysql.connector.connect(host='localhost',
									database='patientdatabase',
									user='root',
									password='*****')
	if conn.is_connected():
		print('Connected to database')
	choice=int(input("Enter your choice:\n1.insert\n2.Retrieve\n3.Exit: "))
	while(1):
		if choice==1:
			insert_procedure(conn)
		elif choice==2:
			retrieve_procedure(conn)
		else:
			conn.close()
			break
		choice=int(input("\nEnter your choice:\n1.insert\n2.Retrieve\n3.Exit: "))


def insert_procedure(conn):
	''' To insert the values '''
	cursor=conn.cursor()

	# values to be added from the user
	choice='y'
	while(choice=='y'):
		print("Enter the values:")
		procedure_id=input("Enter Procedure_id:")
		patient_id=input("Enter patient_id:")
		physician_id=input("Enter physician_id:")
		visit_id=input("Enter visit_id:")
		procedure_coding_method= input("Enter procedure_coding_method:")
		procedure_code=input("Enter procedure_code:")
		procedure_date=input("Enter procedure_date: ")
		
		try:
			
			query="insert into procedures values(%s,%s,%s,%s,%s,%s,%s)"
			args=(procedure_id, patient_id, physician_id , visit_id, procedure_coding_method, procedure_code, procedure_date)

			cursor.execute(query,args)
			conn.commit()
			print ("\nValues inserted\n")
			choice=input("Add more values? y: ")
		except Error as e:
			print (e)


def retrieve_procedure(conn):
	
	cursor=conn.cursor()

	# create the query
	query="select * from procedures"

	# execute  query and fetchall
	cursor.execute(query)
	
	rows=cursor.fetchall()

	for row in rows:
		print (row)
connect()

